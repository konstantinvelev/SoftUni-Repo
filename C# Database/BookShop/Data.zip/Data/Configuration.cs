﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-AJ135QJ\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}