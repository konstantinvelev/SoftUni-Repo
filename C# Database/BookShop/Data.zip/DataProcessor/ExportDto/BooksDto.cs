﻿namespace BookShop.DataProcessor.ExportDto
{
    public class BooksDto
    {
        public string BookName { get; set; }

        public string BookPrice { get; set; }
    }
}