﻿namespace VaporStore.Data.Models.Enumerations
{
    public enum PurchaseType
    {
        Retail = 1,
        Digital = 2
    }
}
