﻿namespace VaporStore
{
	using AutoMapper;

	public class VaporStoreProfile : Profile
	{
		public VaporStoreProfile()
		{
		}
	}
}