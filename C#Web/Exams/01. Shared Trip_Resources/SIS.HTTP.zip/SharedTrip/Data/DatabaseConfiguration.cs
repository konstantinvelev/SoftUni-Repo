﻿namespace SharedTrip
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-AJ135QJ;Database=SharedTrip;Trusted_Connection=True;Integrated Security=True;";
    }
}