﻿using SharedTrip.Models;
using System.Collections.Generic;

namespace SharedTrip.ViewModels.Users
{
   public class HomeViewModel
    { 
        public List<Trip> Trips { get; set; }
    }
}
